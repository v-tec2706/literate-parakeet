#!/usr/bin/env python
#
# Copyright (c) ZeroC, Inc. All rights reserved.
#

import os, sys
sys.path.append(os.path.join(os.path.dirname(__file__), "..", "scripts"))

from Util import runTestsWithPath

runTestsWithPath(__file__)
