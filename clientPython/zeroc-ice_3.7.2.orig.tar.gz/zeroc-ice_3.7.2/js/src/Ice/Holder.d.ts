//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

declare module "ice"
{
    namespace Ice
    {
        class Holder<T>
        {
            value:T;
        }
    }
}
