//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

const Ice = require("../Ice/ModuleRegistry").Ice;
Ice.CompactIdRegistry = new Map();
module.exports.Ice = Ice;
