//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

package com.zeroc.IceGridGUI.LiveDeployment;

import com.zeroc.IceGridGUI.*;

public abstract class Editor extends EditorBase
{
}
