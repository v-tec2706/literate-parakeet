//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

package com.zeroc.IceGridGUI.LiveDeployment;

public interface MetricsFieldContext
{
    public int getRefreshPeriod();
}
