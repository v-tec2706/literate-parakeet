//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

package com.zeroc.IceGridGUI;

public interface StatusBar
{
    void setText(String text);
    void setConnected(boolean connected);
}
