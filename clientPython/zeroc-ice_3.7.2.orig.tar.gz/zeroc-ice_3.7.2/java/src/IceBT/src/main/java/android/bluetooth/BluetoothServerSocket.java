//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

//
// This is a placeholder for the Android API. It is not included in the IceBT JAR file.
//

package android.bluetooth;

public final class BluetoothServerSocket implements java.io.Closeable
{
    public BluetoothSocket accept()
        throws java.io.IOException
    {
        return null;
    }

    public void close()
        throws java.io.IOException
    {
    }
}
