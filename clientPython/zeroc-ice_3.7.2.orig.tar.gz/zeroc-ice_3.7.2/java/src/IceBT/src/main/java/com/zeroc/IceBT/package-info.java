//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

/**
 * APIs for the IceBT plug-in, a Bluetooth transport currently available
 * only for Android.
 **/
package com.zeroc.IceBT;
