//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

/**
 * APIs for clients of the IceGrid location service.
 **/
package com.zeroc.IceGrid;
