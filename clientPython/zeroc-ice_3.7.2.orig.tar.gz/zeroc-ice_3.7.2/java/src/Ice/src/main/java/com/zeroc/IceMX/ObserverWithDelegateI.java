//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

package com.zeroc.IceMX;

public class ObserverWithDelegateI extends ObserverWithDelegate<Metrics, com.zeroc.Ice.Instrumentation.Observer>
{
}
