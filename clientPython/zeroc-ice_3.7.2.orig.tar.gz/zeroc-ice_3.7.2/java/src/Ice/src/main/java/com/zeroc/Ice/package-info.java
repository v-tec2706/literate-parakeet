//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

/**
 * Core APIs of the Ice framework.
 **/
package com.zeroc.Ice;
