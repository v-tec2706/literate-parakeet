//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

package com.zeroc.Ice;

/** @hidden */
public interface MarshaledResult
{
    OutputStream getOutputStream();
}
