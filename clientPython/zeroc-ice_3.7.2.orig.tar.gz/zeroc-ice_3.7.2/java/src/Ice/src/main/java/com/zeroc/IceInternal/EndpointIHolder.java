//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

package com.zeroc.IceInternal;

public final class EndpointIHolder
{
    public EndpointI value;
}
