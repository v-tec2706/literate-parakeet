//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

/**
 * APIs for the IceDiscovery plug-in. IceDiscovery lets client applications
 * discover servers using UDP multicast.
 **/
package com.zeroc.IceDiscovery;
