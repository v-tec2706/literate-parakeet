//
// Copyright (c) ZeroC, Inc. All rights reserved.
//

/**
 * APIs for creating IceBox services and interacting with the IceBox server.
 **/
package com.zeroc.IceBox;
