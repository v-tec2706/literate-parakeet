mod debian/ice.ini
